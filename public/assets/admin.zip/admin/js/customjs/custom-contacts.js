﻿$('.ui.modal').modal('attach events', ".mdlcontact");//add contact modal trigger
$('table').tablesort();//tablesort plugin trigger