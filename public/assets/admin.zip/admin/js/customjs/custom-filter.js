﻿//filter page filterizr triggers
'use strict'
var filterizd = $('.filtr-container').filterizr({
    delay: 10, delayMode: 'progressive'//or delayMode: 'alternate'
});