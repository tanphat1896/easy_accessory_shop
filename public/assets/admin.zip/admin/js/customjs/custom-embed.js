﻿$(".ui.embed").embed();//embed page embed trigger
