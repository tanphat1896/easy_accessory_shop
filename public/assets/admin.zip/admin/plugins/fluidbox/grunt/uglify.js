module.exports = {
    all: {
        files: {
        	'dist/js/jquery.fluidbox.min.js': 'src/js/jquery.fluidbox.js'
        }
    }
};