module.exports = {
    all: [
        "dist/"
    ]
};